/* MontaCerto — site institucional. Sem dependências externas. */
(function () {
  "use strict";
  var doc = document.documentElement;
  var movimento = doc.classList.contains("js-movimento");
  var $ = function (sel, el) { return (el || document).querySelector(sel); };
  var $$ = function (sel, el) { return Array.prototype.slice.call((el || document).querySelectorAll(sel)); };
  var temIO = "IntersectionObserver" in window;

  /* ---------- "Acessar sistema": quem já tem sessão aberta vai direto ---------- */
  try {
    var destino = "/login";
    if (sessionStorage.getItem("ep_gestor")) destino = "/painel";
    else if (sessionStorage.getItem("loja_sessao")) destino = "/loja.html";
    $$("[data-acesso]").forEach(function (a) { a.setAttribute("href", destino); });
  } catch (e) { /* armazenamento indisponível: mantém /login */ }

  /* ---------- cabeçalho: sombra ao rolar ---------- */
  var cab = $("#cabecalho");
  if (temIO && cab) {
    var sentinela = document.createElement("div");
    sentinela.style.cssText = "position:absolute;top:0;left:0;width:1px;height:24px;pointer-events:none";
    document.body.prepend(sentinela);
    new IntersectionObserver(function (e) { cab.classList.toggle("rolou", !e[0].isIntersecting); }).observe(sentinela);
  }

  /* ---------- menu no celular ---------- */
  var menuBotao = $(".menu-botao");
  var menu = $("#menu-sobreposto");
  function fecharMenu(focarBotao) {
    doc.classList.remove("menu-aberto");
    if (menuBotao) { menuBotao.setAttribute("aria-expanded", "false"); menuBotao.setAttribute("aria-label", "Abrir menu"); }
    if (menu) menu.setAttribute("inert", "");
    if (focarBotao && menuBotao) menuBotao.focus();
  }
  if (menu) menu.setAttribute("inert", "");
  if (menuBotao && menu) {
    menuBotao.addEventListener("click", function () {
      var abrir = !doc.classList.contains("menu-aberto");
      if (!abrir) return fecharMenu(false);
      doc.classList.add("menu-aberto");
      menu.removeAttribute("inert");
      menuBotao.setAttribute("aria-expanded", "true");
      menuBotao.setAttribute("aria-label", "Fechar menu");
      var primeiro = $("a", menu); if (primeiro) setTimeout(function () { primeiro.focus(); }, 80);
    });
    $$("a", menu).forEach(function (a) { a.addEventListener("click", function () { fecharMenu(false); }); });
    document.addEventListener("keydown", function (e) { if (e.key === "Escape" && doc.classList.contains("menu-aberto")) fecharMenu(true); });
    window.addEventListener("resize", function () { if (window.innerWidth >= 900 && doc.classList.contains("menu-aberto")) fecharMenu(false); });
  }

  /* ---------- link da seção atual ---------- */
  var linksNav = $$(".nav-links a[data-secao]");
  if (temIO && linksNav.length) {
    var visiveis = {};
    var obsSecao = new IntersectionObserver(function (entradas) {
      entradas.forEach(function (en) { visiveis[en.target.id] = en.isIntersecting; });
      var atual = null;
      linksNav.forEach(function (a) { if (!atual && visiveis[a.dataset.secao]) atual = a.dataset.secao; });
      linksNav.forEach(function (a) {
        var on = a.dataset.secao === atual;
        a.classList.toggle("atual", on);
        if (on) a.setAttribute("aria-current", "location"); else a.removeAttribute("aria-current");
      });
    }, { rootMargin: "-45% 0px -50% 0px" });
    linksNav.forEach(function (a) { var s = document.getElementById(a.dataset.secao); if (s) obsSecao.observe(s); });
  }

  /* ---------- entrada suave dos blocos ---------- */
  function quandoVisivel(el, cb, opcoes) {
    if (!el) return;
    if (!temIO) { cb(); return; }
    var o = new IntersectionObserver(function (en) {
      if (en[0].isIntersecting) { o.disconnect(); cb(); }
    }, opcoes || { threshold: 0.15 });
    o.observe(el);
  }
  if (movimento && temIO) {
    var obsSurge = new IntersectionObserver(function (entradas) {
      entradas.forEach(function (en) { if (en.isIntersecting) { en.target.classList.add("visivel"); obsSurge.unobserve(en.target); } });
    }, { rootMargin: "0px 0px -8% 0px", threshold: 0.01 });
    $$(".surge").forEach(function (el) { obsSurge.observe(el); });
  } else {
    $$(".surge").forEach(function (el) { el.classList.add("visivel"); });
  }

  /* ==========================================================
     1. Abertura: um serviço do início ao fim, em 5 etapas
     ========================================================== */
  var etapas = $$(".etapa");
  var legenda = $("#legenda-historia");
  var rever = $("#rever-historia");
  var LEGENDAS = [
    "O pedido entra na lista de serviços do dia, com cliente e bairro.",
    "Cada serviço fica com um montador responsável.",
    "O montador recebe o aviso e encontra o serviço na rota dele.",
    "Com um toque, ele informa que está a caminho.",
    "A mesma atualização aparece no painel de quem organiza."
  ];
  var el = {
    linha: $("#h-linha"), montador: $("#h-montador"), status: $("#h-status"),
    cartao: $("#h-cartao"), caminho: $("#h-caminho"), aviso: $("#h-aviso"),
    painelDepois: $("#h-painel-depois"), celStatus: $("#h-celular-status")
  };
  var timers = [];
  function limparTimers() { timers.forEach(clearTimeout); timers = []; }
  function liga(n, on) { if (n) n.classList.toggle(n.classList.contains("camada") ? "ativa" : "ativo", !!on); }
  function irParaEtapa(n) {
    limparTimers();
    etapas.forEach(function (b) {
      var k = +b.dataset.etapa;
      b.setAttribute("aria-pressed", k === n ? "true" : "false");
      b.classList.toggle("feita", k < n);
    });
    if (legenda) legenda.textContent = LEGENDAS[n - 1];
    liga(el.linha, n === 1);
    liga(el.montador, n === 2);
    liga(el.aviso, n === 3);
    liga(el.cartao, false);
    if (n === 3) timers.push(setTimeout(function () { liga(el.cartao, true); }, movimento ? 700 : 0));
    liga(el.celStatus, n >= 4);
    liga(el.caminho, n === 4);
    liga(el.painelDepois, n >= 5);
    liga(el.status, n === 5);
  }
  var autoplay = null;
  function pararAuto() { if (autoplay) { clearInterval(autoplay); autoplay = null; } }
  function tocarHistoria() {
    pararAuto();
    if (rever) rever.hidden = true;
    var n = 1;
    irParaEtapa(n);
    autoplay = setInterval(function () {
      n++;
      irParaEtapa(n);
      if (n >= 5) { pararAuto(); if (rever) rever.hidden = false; }
    }, 2600);
  }
  etapas.forEach(function (b) {
    b.addEventListener("click", function () { pararAuto(); irParaEtapa(+b.dataset.etapa); if (rever) rever.hidden = false; });
  });
  if (rever) rever.addEventListener("click", function () { tocarHistoria(); var e1 = etapas[0]; if (e1) e1.focus({ preventScroll: true }); });
  if (etapas.length) {
    if (movimento) {
      quandoVisivel($("#composicao"), function () { setTimeout(tocarHistoria, 700); }, { threshold: 0.35 });
    } else {
      irParaEtapa(5);
      if (rever) rever.hidden = true;
    }
  }

  /* ==========================================================
     2. Demonstração por perfil
     ========================================================== */
  var abas = $$('.perfis [role="tab"]');
  function selecionarAba(aba, focar) {
    abas.forEach(function (a) {
      var sel = a === aba;
      a.setAttribute("aria-selected", sel ? "true" : "false");
      a.tabIndex = sel ? 0 : -1;
      var painel = document.getElementById(a.getAttribute("aria-controls"));
      if (!painel) return;
      if (sel) {
        painel.hidden = false;
        if (movimento) { painel.classList.remove("entrando"); void painel.offsetWidth; painel.classList.add("entrando"); }
      } else painel.hidden = true;
    });
    if (focar) aba.focus();
  }
  abas.forEach(function (aba, i) {
    aba.addEventListener("click", function () { selecionarAba(aba, false); });
    aba.addEventListener("keydown", function (e) {
      var alvo = null;
      if (e.key === "ArrowRight" || e.key === "ArrowDown") alvo = abas[(i + 1) % abas.length];
      if (e.key === "ArrowLeft" || e.key === "ArrowUp") alvo = abas[(i - 1 + abas.length) % abas.length];
      if (e.key === "Home") alvo = abas[0];
      if (e.key === "End") alvo = abas[abas.length - 1];
      if (alvo) { e.preventDefault(); selecionarAba(alvo, true); }
    });
  });

  $$(".painel-perfil").forEach(function (painel) {
    function ativarPonto(n) {
      $$("[data-ponto]", painel).forEach(function (b) { b.setAttribute("aria-pressed", b.dataset.ponto === String(n) ? "true" : "false"); });
      $$("[data-area]", painel).forEach(function (d) { d.classList.toggle("ativo", d.dataset.area === String(n)); });
      $$("[data-foco]", painel).forEach(function (f) { f.classList.toggle("visivel", f.dataset.foco === String(n)); });
    }
    $$("[data-ponto]", painel).forEach(function (b) {
      b.addEventListener("click", function () { ativarPonto(b.dataset.ponto); });
    });
    ativarPonto(1);
  });

  /* ---------- ampliar imagem ---------- */
  var dialogo = $("#ampliacao");
  var corpo = $("#ampliacao-corpo");
  var tituloDialogo = $("#ampliacao-titulo");
  var origemFoco = null;
  var GRUPOS = {
    monta: [
      { src: "/site/img/app-rota-1170.webp", alt: "Rota do dia no aplicativo do montador, com dados de demonstração." },
      { src: "/site/img/app-detalhe-1170.webp", alt: "Detalhe de um serviço: endereço, referência e contato." },
      { src: "/site/img/app-status-1170.webp", alt: "Tela de atualizar status no aplicativo do montador." }
    ]
  };
  function abrirAmpliacao(botao) {
    if (!dialogo || !corpo) return;
    corpo.innerHTML = "";
    var itens = botao.dataset.ampliarGrupo ? GRUPOS[botao.dataset.ampliarGrupo] : [{ src: botao.dataset.ampliar, alt: botao.dataset.alt || "" }];
    var estreita = botao.hasAttribute("data-estreita") || !!botao.dataset.ampliarGrupo;
    if (botao.dataset.ampliarGrupo) corpo.style.cssText = "display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:16px;align-items:start";
    else corpo.style.cssText = "";
    itens.forEach(function (it) {
      var img = new Image();
      img.src = it.src; img.alt = it.alt; img.decoding = "async";
      if (estreita) img.className = "estreita";
      corpo.appendChild(img);
    });
    if (tituloDialogo) tituloDialogo.textContent = botao.dataset.titulo || "Imagem ampliada";
    origemFoco = botao;
    if (typeof dialogo.showModal === "function") dialogo.showModal();
    else window.open(itens[0].src, "_blank", "noopener");
  }
  $$("[data-ampliar], [data-ampliar-grupo]").forEach(function (b) { b.addEventListener("click", function () { abrirAmpliacao(b); }); });
  if (dialogo) {
    var fechar = $("#fechar-ampliacao");
    if (fechar) fechar.addEventListener("click", function () { dialogo.close(); });
    dialogo.addEventListener("click", function (e) { if (e.target === dialogo) dialogo.close(); });
    dialogo.addEventListener("close", function () { if (origemFoco) origemFoco.focus(); });
  }

  /* ==========================================================
     3. Jornada: cartões dispersos se organizam e viram o painel
     ========================================================== */
  var org = $("#organizacao");
  var reverOrg = $("#rever-organizacao");
  var timersOrg = [];
  function tocarOrganizacao() {
    if (!org) return;
    timersOrg.forEach(clearTimeout); timersOrg = [];
    if (reverOrg) reverOrg.hidden = true;
    org.setAttribute("data-estado", "disperso");
    timersOrg.push(setTimeout(function () { org.setAttribute("data-estado", "organizado"); }, 700));
    timersOrg.push(setTimeout(function () { org.setAttribute("data-estado", "painel"); }, 3000));
    timersOrg.push(setTimeout(function () { if (reverOrg) reverOrg.hidden = false; }, 4200));
  }
  if (org && movimento) {
    org.setAttribute("data-estado", "disperso");
    quandoVisivel(org, tocarOrganizacao, { threshold: 0.4 });
    if (reverOrg) reverOrg.addEventListener("click", tocarOrganizacao);
  }
  quandoVisivel($("#marcos"), function () { $("#marcos").classList.add("visivel"); }, { threshold: 0.3 });

  /* ---------- frase: palavra por palavra ---------- */
  var frase = $("#frase-conceito");
  if (frase) {
    var palavras = frase.textContent.trim().split(/\s+/);
    var destaqueDe = palavras.length - 4; // "do início ao fim."
    frase.innerHTML = '<span class="sr-only">' + frase.textContent.trim() + "</span>" + palavras.map(function (p, i) {
      return '<span class="palavra' + (i >= destaqueDe ? " destaque-texto" : "") + '" aria-hidden="true">' + p + "</span>";
    }).join(" ");
    if (movimento && temIO) {
      var obsPalavra = new IntersectionObserver(function (entradas) {
        entradas.forEach(function (en) {
          if (en.isIntersecting) { en.target.classList.add("acesa"); obsPalavra.unobserve(en.target); }
        });
      }, { rootMargin: "0px 0px -42% 0px", threshold: 1 });
      $$(".palavra", frase).forEach(function (s, i) {
        s.style.transitionDelay = (i % 3) * 40 + "ms";
        obsPalavra.observe(s);
      });
    }
  }

  /* ---------- convite: a marca se forma ---------- */
  var convite = $("#convite");
  quandoVisivel(convite, function () { convite.classList.add("visivel"); }, { threshold: 0.35 });
})();
